<?php
require 'functions.php';
$name = 'Home';
$conn = koneksi();

require 'view/index.view.php';
    