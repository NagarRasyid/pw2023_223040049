<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark p-3" id="navbar">
    <div class="container-fluid">
      <a class="navbar-brand <?= uriIs(BASE_URL); ?>" href="<?= BASE_URL; ?>">Ciumbuleuit</a>
    </div>
  </nav>