<?php require('partial/head.php'); ?>
<?php require('partial/nav.php'); ?>

<main>
  <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active" style="background-image: url(img/Warung\ sate\ bu\ ngantuk2.png); background-size: cover; background-repeat: no-repeat;">
      <div class="overlay-image"></div>
        <svg class="bd-placeholder-img" width="100%" height="100%" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"></svg>
        <div class="container">
          <div class="carousel-caption text-start">
            <h1>Example headline.</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim, dolores..</p>
            <p><a class="btn btn-lg btn-primary" href="#">Sign up today</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item" style="background-image: url(img/Ayam\ Goreng\ Penyet\ Kabita.png); background-size: cover; background-repeat: no-repeat; ">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"></svg>
        <div class="container">
          <div class="carousel-caption">
          <h1>Another example headline.</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugiat, eaque!.</p>
            <p><a class="btn btn-lg btn-primary" href="#">Learn more</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item" style="background-image: url(img/Bakso\ Solo\ pak\ gilang.png); background-size: cover; background-repeat: no-repeat;">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"></svg>
        <div class="container">
          <div class="carousel-caption text-end">
            <h1>One more for good measure.</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum, quasi..</p>
            <p><a class="btn btn-lg btn-primary" href="#">Browse gallery</a></p>
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  
  <div class="container marketing">
    <div class="row justify-content-around">
      <div class="card me-4" style="width: 18rem;">
        <img src="img/SateThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Sate Bu Ngantuk</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/AyamPenyetThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Ayam Goreng Penyet Kabita</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/BaksoThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Bakso Solo Pak Gilang</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/SateThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Sate Bu Ngantuk</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/AyamPenyetThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Ayam Goreng Penyet Kabita</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/BaksoThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Bakso Solo Pak Gilang</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/SateThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Sate Bu Ngantuk</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/AyamPenyetThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Ayam Goreng Penyet Kabita</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/BaksoThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Bakso Solo Pak Gilang</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/SateThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Sate Bu Ngantuk</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/AyamPenyetThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Ayam Goreng Penyet Kabita</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
      <div class="card me-4" style="width: 18rem;">
        <img src="img/BaksoThumb.png" alt="">
        <h4 class="fw-normal"><a href="">Bakso Solo Pak Gilang</a></h4>
        <p>Makanan Indonesia.</p>
        <p><a class="btn btn-secondary" href="#">View details &raquo;</a></p>
      </div>
    </div>
  </div>
</main>
<footer class="footer">
    <div class="text-center p-5" style="background: #CCCCCC;">
      <p>Copyright &copy; 2023. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
    </div>
</footer>
<?php require('partial/footer.php'); ?>
