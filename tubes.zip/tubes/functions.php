<?php 
define('BASE_URL', '/pw2023_223040049/tubes/');

function koneksi()
{
  $conn = mysqli_connect('localhost', 'root', '', 'tubes') or die('Koneksi ke Database gagal');
  return $conn;
}

function query($query)
{
  $conn = koneksi();
  $result = mysqli_query($conn, $query);

  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }

  return $rows;
}

function registrasi($data) {
  $conn =  koneksi();
  $username = htmlspecialchars($data['username']);
  $email = htmlspecialchars($data['email']);
  $password = mysqli_real_escape_string($conn,$data['password']);
  $confirm_password = mysqli_real_escape_string($conn,$data['confirm_password']);

  $query = "SELECT username
            FROM user
            WHERE username = '$username'";
  if(query($query)) {
    echo "<script> alert('username sudah terdaftar')</script>";
    return false;
  }

  if($password !== $confirm_password) {
    echo "<script> alert('konfirmasi password tidak sesuai!'); </script>";
    return false;
  }

  $password = password_hash($password, PASSWORD_DEFAULT);

  $query = "INSERT INTO user
            VALUES (null,'$username','$email','$password')";

  mysqli_query($conn, $query) or die(mysqli_error($conn));

  return mysqli_affected_rows($conn);
}

// function login($data) {
//   $conn = koneksi();
//   $username = htmlspecialchars($data ['username']);
//   $password = htmlspecialchars($data['password']);

//   if($user = query("SELECT * FROM user WHERE username = '$username'")[0]
//   {
//     //cek password
//     if(password_verify($password, $user['password'])) {
//       // set session
//       $_SESSION['login'] = true;

//       //jika admin
//       if($user['status'] == 'admin') {
//         $_SESSION['status'] = 'admin';
//         header("Location: admin/index.php");
//         exit;
//       }else {
//         //jika user
//         $_SESSION['status'] = 'user';
//         header("Location: index.php");
//         exit;
//       }
//     }
//   })
// }

function tambah($data)
{
  $conn =  koneksi();
  $username = htmlspecialchars($data['username']);
  $email = htmlspecialchars($data['email']);
  $password = mysqli_real_escape_string($conn,$data['password']);

  $password = password_hash($password, PASSWORD_DEFAULT);

  $query = "INSERT INTO
            user
            VALUES (null,'$username','$email','$password')";

  mysqli_query($conn, $query) or die(mysqli_error($conn));

  return mysqli_affected_rows($conn);
}


function hapus($id) {
  $conn = koneksi();
  $query = "DELETE FROM user WHERE id= $id";

  mysqli_query($conn, $query) or die (mysqli_error($conn));
  return mysqli_affected_rows($conn);
}

function ubah($data)
{
  $conn =  koneksi();
  $id = htmlspecialchars($data['id']);
  $username = htmlspecialchars($data['username']);
  $email = htmlspecialchars($data['email']);
  $password = mysqli_real_escape_string($conn,$data['password']);

  $password = password_hash($password, PASSWORD_DEFAULT);

  $query = "UPDATE
            user
            SET
            username = '$username',
            email = '$email',
            password = '$password'
            WHERE 
            id = $id 
            ";

  mysqli_query($conn, $query) or die(mysqli_error($conn));

  return mysqli_affected_rows($conn);
}



function dd($value)
{
  echo "<pre>";
  var_dump($value);
  die;
  echo "</pre>";
}

function uriIS($uri)
{
  return ($_SERVER["REQUEST_URI"] === BASE_URL) ? 'active' : '';
}
?>