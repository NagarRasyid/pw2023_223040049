<?php require('partial/head.php'); ?>
<?php require('partial/nav.php'); ?>



<?php require('partial/footer.php'); ?>