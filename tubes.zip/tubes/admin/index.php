<?php
require '../functions.php';
$name = 'Home Admin';
$conn = koneksi();

require 'view/index.view.php';
    